export default function Footer() {
  return (
    <footer className="h-16 border-t border-white/5 relative z-10 px-6 md:px-12 flex flex-col md:flex-row items-center justify-between bg-royal-black gap-4 py-4 md:py-0">
      <div className="flex gap-8 text-[10px] uppercase tracking-[0.2em] opacity-40 text-royal-white">
        <a href="#" className="hover:opacity-100 transition-opacity">Instagram</a>
        <a href="#" className="hover:opacity-100 transition-opacity">Facebook</a>
        <a href="#" className="hover:opacity-100 transition-opacity">Tripadvisor</a>
      </div>
      <div className="text-[9px] uppercase tracking-widest opacity-30 text-royal-white">
        &copy; {new Date().getFullYear()} Royal Spice Culinary Group
      </div>
      <div className="flex items-center gap-4">
        <span className="text-[10px] uppercase tracking-widest opacity-60 text-royal-white">
          Open Daily: 12:00 — 23:00
        </span>
      </div>
    </footer>
  );
}
