import { motion } from 'motion/react';
import { ChefHat, Leaf, Clock, Award } from 'lucide-react';

export default function About() {
  return (
    <div className="w-full">
      {/* Hero Header */}
      <section className="relative h-[50vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
            alt="Restaurant Interior"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-royal-black to-royal-black/50" />
        </div>
        <div className="relative z-10 text-center px-4">
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-4 text-royal-gold">Our Story</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto font-light">A legacy of culinary perfection passed down through generations.</p>
        </div>
      </section>

      {/* Story Content */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="font-serif text-4xl font-bold mb-6 text-royal-white">
              The Genesis of <span className="text-royal-gold">Royal Spice</span>
            </h2>
            <div className="space-y-6 text-gray-400 leading-relaxed font-light">
              <p>
                Founded in 1995, Royal Spice began as a humble dream by Chef Alaric, who wished to bring the forgotten recipes of ancient imperial courts back to life. Every spice, every technique, and every presentation is a tribute to a bygone era of gastronomic excellence.
              </p>
              <p>
                Our mission is simple: to provide an unforgettable dining experience where every guest is treated like royalty. We believe that food is not just sustenance, but an art form that brings people together and creates lasting memories.
              </p>
              <p>
                Today, Royal Spice stands as a beacon of fine dining, constantly innovating while staying true to our roots. We carefully source our ingredients from artisanal producers worldwide to maintain the authenticity and quality of our diverse menu.
              </p>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-royal-gold/20 translate-x-4 translate-y-4 rounded-sm" />
            <img
              src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
              alt="Our Chef"
              className="relative z-10 rounded-sm w-full h-[600px] object-cover grayscale hover:grayscale-0 transition-all duration-700"
            />
          </motion.div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-neutral-900 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold mb-4 text-royal-gold">Our Philosophy</h2>
            <div className="w-24 h-1 bg-royal-red mx-auto" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: ChefHat, title: "Master Chefs", desc: "Our kitchen is led by award-winning culinary artists with decades of experience." },
              { icon: Leaf, title: "Fresh Ingredients", desc: "We source organic and fresh produce daily to ensure the highest quality flavors." },
              { icon: Clock, title: "Slow Cooked", desc: "Perfection takes time. Many of our signature dishes are slow-cooked overnight." },
              { icon: Award, title: "Premium Quality", desc: "We never compromise on quality, offering a consistent five-star experience." }
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="p-8 bg-royal-black text-center group hover:-translate-y-2 transition-transform duration-300 border border-transparent hover:border-royal-gold/30 rounded-sm"
              >
                <div className="w-16 h-16 mx-auto bg-neutral-900 rounded-full flex items-center justify-center mb-6 group-hover:bg-royal-gold transition-colors">
                  <feature.icon className="w-8 h-8 text-royal-gold group-hover:text-royal-black transition-colors" />
                </div>
                <h3 className="font-serif text-xl font-bold mb-3 text-royal-white">{feature.title}</h3>
                <p className="text-gray-400 text-sm">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
