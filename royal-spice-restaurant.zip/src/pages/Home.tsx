import { motion } from 'motion/react';
import { NavLink } from 'react-router-dom';
import { ChevronRight, Star } from 'lucide-react';

const featuredDishes = [
  {
    id: 1,
    name: 'Royal Saffron Biryani',
    description: 'Fragrant basmati rice cooked with tender meat, infused with pure saffron and exotic spices.',
    price: '$28',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 2,
    name: 'Butter Chicken Masala',
    description: 'Tender chicken pieces simmered in a rich, creamy tomato and butter sauce.',
    price: '$24',
    image: 'https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 3,
    name: 'Golden Paneer Tikka',
    description: 'Cottage cheese cubes marinated in yogurt and rare spices, grilled in a clay oven.',
    price: '$18',
    image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  },
];

const testimonials = [
  {
    name: 'Eleanor Vance',
    role: 'Food Critic',
    text: 'A truly magnificent dining experience. Every dish is a masterpiece of flavor and presentation.',
    rating: 5,
  },
  {
    name: 'Marcus Sterling',
    role: 'Local Guide',
    text: 'The ambiance is breathtaking and the staff treats you like royalty from the moment you step in.',
    rating: 5,
  },
  {
    name: 'Sophia Laurent',
    role: 'Regular Guest',
    text: 'I celebrate all my special occasions here. The Royal Saffron Biryani is an absolute must-try.',
    rating: 5,
  },
];

export default function Home() {
  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1544025162-836e4f3a76cd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
            alt="Royal Spice Restaurant"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-royal-black via-royal-black/60 to-transparent" />
        </div>

        <div className="relative z-10 px-6 max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-7 flex flex-col justify-center">
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="relative font-serif text-[64px] md:text-[84px] leading-[0.9] italic text-royal-white mb-6 text-left"
            >
              <div className="absolute -left-6 top-3 w-1 h-24 bg-royal-red hidden md:block" />
              Taste the <br />
              <span className="text-royal-gold not-italic">Royal</span> <br />
              Experience
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-sm leading-relaxed mb-10 max-w-md text-gray-300 tracking-wide text-left"
            >
              Indulge in a curated symphony of authentic spices and premium ingredients, where every dish tells a story of heritage and culinary mastery.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="flex flex-col sm:flex-row items-start sm:items-center gap-6"
            >
              <NavLink
                to="/menu"
                className="bg-royal-red hover:bg-royal-red-hover text-royal-white px-10 py-4 text-[10px] uppercase tracking-[0.2em] font-semibold transition-all duration-300"
              >
                View the Menu
              </NavLink>
              <div className="flex items-center gap-4 text-royal-white">
                <span className="h-[1px] w-12 bg-white/30" />
                <span className="text-[10px] uppercase tracking-widest opacity-60">Est. 1994</span>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Dishes */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4 text-royal-gold">Our Signature Plates</h2>
          <div className="w-24 h-1 bg-royal-red mx-auto mb-6" />
          <p className="text-gray-400 max-w-2xl mx-auto">
            Discover the dishes that have defined our legacy. Each recipe is crafted with precision, using only the finest ingredients sourced globally.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {featuredDishes.map((dish, index) => (
            <motion.div
              key={dish.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group cursor-pointer bg-royal-card border border-white/5 p-4 flex flex-col gap-4 relative overflow-hidden"
            >
              <div className="absolute top-4 right-4 z-10">
                <span className="text-[10px] uppercase tracking-widest text-royal-gold bg-royal-gold/10 px-3 py-1.5">Featured</span>
              </div>
              <div className="w-full h-48 bg-gradient-to-br from-[#2a2a2a] to-[#111] overflow-hidden border border-white/5">
                <img
                  src={dish.image}
                  alt={dish.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-80 group-hover:opacity-100"
                />
              </div>
              <div className="flex flex-col justify-center flex-grow pt-2">
                <h3 className="font-serif text-xl text-royal-gold mb-1">
                  {dish.name}
                </h3>
                <p className="text-xs opacity-50 mb-3">
                  {dish.description}
                </p>
                <div className="flex justify-between items-center mt-auto">
                  <span className="text-lg font-serif italic text-royal-white">{dish.price}</span>
                  <NavLink to="/menu" className="text-royal-gold text-[10px] uppercase tracking-widest flex items-center gap-2 hover:gap-3 transition-all">
                    Order Now <ChevronRight className="w-3 h-3" />
                  </NavLink>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-neutral-900 border-y border-white/5 relative overflow-hidden">
        {/* Background Accent */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-royal-red/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4 text-royal-gold">Guest Memoirs</h2>
            <div className="w-24 h-1 bg-royal-red mx-auto mb-6" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((test, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-royal-black p-8 rounded-sm border border-white/5 shadow-xl"
              >
                <div className="flex gap-1 text-royal-gold mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <p className="text-gray-300 italic mb-8 relative">
                  <span className="text-4xl absolute -top-4 -left-2 text-white/10 font-serif">"</span>
                  <span className="relative z-10">{test.text}</span>
                  <span className="text-4xl absolute -bottom-8 right-0 text-white/10 font-serif rotate-180">"</span>
                </p>
                <div className="flex flex-col">
                  <span className="font-serif font-semibold text-royal-white">{test.name}</span>
                  <span className="text-xs text-royal-gold uppercase tracking-wider mt-1">{test.role}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
