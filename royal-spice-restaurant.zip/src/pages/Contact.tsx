import { motion } from 'motion/react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export default function Contact() {
  return (
    <div className="w-full pt-24 pb-0">
      {/* Header Container */}
      <div className="max-w-7xl mx-auto px-6 mb-16 text-center">
        <h1 className="font-serif text-5xl md:text-6xl font-bold mb-4 text-royal-gold">Contact Us</h1>
        <div className="w-24 h-1 bg-royal-red mx-auto mb-6" />
        <p className="text-gray-400 max-w-2xl mx-auto">
          We would love to hear from you. For special inquiries, private dining, or feedback, please reach out to us using the information below.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-3 gap-16 mb-24">
        {/* Info Cards */}
        <div className="col-span-1 space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-start gap-4"
          >
            <div className="w-12 h-12 bg-neutral-900 rounded-full flex items-center justify-center shrink-0">
              <MapPin className="w-5 h-5 text-royal-gold" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-royal-white mb-2">Location</h3>
              <p className="text-gray-400 font-light">
                123 Royal Avenue<br />
                Culinary District<br />
                Metropolis, NY 10001
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="flex items-start gap-4"
          >
            <div className="w-12 h-12 bg-neutral-900 rounded-full flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5 text-royal-gold" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-royal-white mb-2">Hours</h3>
              <p className="text-gray-400 font-light">
                Mon - Fri: 5:00 PM - 11:30 PM<br />
                Sat - Sun: 12:00 PM - 12:00 AM
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="flex items-start gap-4"
          >
            <div className="w-12 h-12 bg-neutral-900 rounded-full flex items-center justify-center shrink-0">
              <Phone className="w-5 h-5 text-royal-gold" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-royal-white mb-2">Phone</h3>
              <p className="text-gray-400 font-light">+1 (555) 123-4567</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="flex items-start gap-4"
          >
            <div className="w-12 h-12 bg-neutral-900 rounded-full flex items-center justify-center shrink-0">
              <Mail className="w-5 h-5 text-royal-gold" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-royal-white mb-2">Email</h3>
              <p className="text-gray-400 font-light">info@royalspice.com</p>
            </div>
          </motion.div>
        </div>

        {/* Map Placeholder */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="col-span-1 lg:col-span-2 relative h-[400px] lg:h-auto rounded-sm overflow-hidden group border border-white/10"
        >
          {/* Aesthetic Map Image Placeholder (Since we can't easily iframe a real GMap straight without API keys, we use a beautifully stylized map image) */}
          <div className="absolute inset-0 bg-neutral-800 animate-pulse" /> {/* Loading skeleton */}
          <img
            src="https://images.unsplash.com/photo-1524661135-423995f22d0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80"
            alt="Map Location"
            className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-luminosity hover:mix-blend-normal transition-all duration-700"
          />
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-16 h-16 bg-royal-gold/20 rounded-full flex items-center justify-center animate-ping absolute" />
            <div className="bg-royal-black text-royal-gold p-3 rounded-full pointer-events-auto cursor-pointer hover:scale-110 transition-transform shadow-2xl">
              <MapPin className="w-6 h-6" />
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
