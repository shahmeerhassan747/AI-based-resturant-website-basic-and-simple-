import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

const menuData = {
  Starters: [
    { name: "Truffle Mushroom Soup", desc: "Wild mushrooms gently simmered with cream and white truffle oil.", price: "$14" },
    { name: "Golden Calamari Rings", desc: "Crispy fried calamari served with zesty lemon aioli.", price: "$18" },
    { name: "Saffron Arancini", desc: "Stuffed risotto balls with mozzarella and delicate saffron threads.", price: "$16" },
    { name: "Spicy Lamb Kebabs", desc: "Minced lamb infused with aromatic spices, grilled over charcoal.", price: "$22" },
  ],
  "Main Course": [
    { name: "Royal Saffron Biryani", desc: "Fragrant basmati rice cooked with tender meat, infused with pure saffron.", price: "$28" },
    { name: "Butter Chicken Masala", desc: "Tender chicken pieces simmered in a rich, creamy tomato and butter sauce.", price: "$24" },
    { name: "Pan-Seared Salmon", desc: "Atlantic salmon with asparagus, lemon butter sauce, and roasted potatoes.", price: "$32" },
    { name: "Wagyu Beef Ribeye", desc: "Premium cut grilled to perfection, served with peppercorn sauce.", price: "$85" },
    { name: "Lobster Ravioli", desc: "Handmade pasta stuffed with lobster meat in a creamy bisque sauce.", price: "$38" },
    { name: "Vegetable Tagine", desc: "Slow-cooked Moroccan stew with seasonal vegetables and couscous.", price: "$22" },
  ],
  Desserts: [
    { name: "24k Gold Chocolate Lava", desc: "Molten dark chocolate cake adorned with edible gold leaf.", price: "$18" },
    { name: "Pistachio Rose Baklava", desc: "Layers of phyllo pastry, pistachios, and rose-water syrup.", price: "$14" },
    { name: "Mango Saffron Mousse", desc: "Light and airy mousse combining sweet mango and delicate saffron.", price: "$12" },
  ],
  Drinks: [
    { name: "The Majestic Mule", desc: "Premium vodka, ginger beer, lime, and crushed cardamom.", price: "$15" },
    { name: "Smoked Old Fashioned", desc: "Aged bourbon, bitters, orange peel, Applewood smoke.", price: "$18" },
    { name: "Rose Petal Martini", desc: "Gin, rose syrup, fresh lemon juice, garnished with petals.", price: "$16" },
  ]
};

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState<keyof typeof menuData>('Starters');
  const categories = Object.keys(menuData) as Array<keyof typeof menuData>;

  return (
    <div className="w-full">
      {/* Header */}
      <section className="relative h-[40vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
            alt="Menu Banner"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-royal-black to-transparent" />
        </div>
        <div className="relative z-10 text-center px-4">
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-4 text-royal-gold">Our Menu</h1>
          <p className="text-lg text-gray-300">Curated specifically for distinguished palates.</p>
        </div>
      </section>

      {/* Menu Content */}
      <section className="py-24 px-6 max-w-5xl mx-auto">
        {/* Category Navigation */}
        <div className="flex flex-wrap justify-center gap-4 mb-16">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-8 py-3 text-[10px] uppercase tracking-[0.2em] font-semibold transition-all duration-300 ${
                activeCategory === category
                  ? 'bg-royal-gold text-royal-black'
                  : 'bg-transparent text-gray-400 border border-white/10 hover:border-royal-gold hover:text-royal-gold'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Menu Items List */}
        <div className="min-h-[500px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10"
            >
              {menuData[activeCategory].map((item, index) => (
                <div key={index} className="group flex flex-col pt-4 border-t border-white/10 border-dashed">
                  <div className="flex justify-between items-baseline mb-2">
                    <h3 className="font-serif text-xl font-bold text-royal-white group-hover:text-royal-gold transition-colors">
                      {item.name}
                    </h3>
                    <div className="flex-grow border-b border-dotted border-white/20 mx-4" />
                    <span className="font-serif text-xl text-royal-gold font-bold">
                      {item.price}
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm font-light pr-12 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>
    </div>
  );
}
