import { useState } from 'react';
import type { FormEvent, ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Clock, Users, CheckCircle } from 'lucide-react';

export default function Reservation() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    guests: '2',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate network request
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="w-full min-h-screen py-24 px-6 relative flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1514933651103-005eec06c04b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
          alt="Restaurant Ambiance"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-royal-black via-royal-black/80 to-royal-black/50" />
      </div>

      <div className="max-w-6xl w-full mx-auto relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        {/* Text Content */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-royal-gold text-sm font-bold tracking-widest uppercase mb-4 block">Reservation</span>
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-6 text-royal-white">
            Book Your Table
          </h1>
          <div className="w-16 h-1 bg-royal-red mb-8" />
          <p className="text-gray-300 text-lg leading-relaxed font-light mb-8 max-w-md">
            Secure your spot for an unforgettable dining experience. Whether it's an intimate dinner or a grand celebration, we look forward to serving you.
          </p>
          <div className="space-y-4">
            <div className="flex items-center gap-4 text-gray-400">
              <Clock className="w-5 h-5 text-royal-gold" />
              <span>Open Daily: 5:00 PM - 11:30 PM</span>
            </div>
          </div>
        </motion.div>

        {/* Form Container */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-royal-gold p-8 md:p-12 shadow-2xl relative text-black"
        >
          <AnimatePresence mode="wait">
            {!isSuccess ? (
              <motion.form
                key="form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onSubmit={handleSubmit}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Name */}
                  <div className="border-b border-black/20 pb-1">
                    <label className="block text-[9px] uppercase tracking-widest font-bold opacity-60 mb-1">Full Name</label>
                    <input
                      required
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full bg-transparent text-sm font-medium focus:outline-none placeholder-black/30 text-black py-2"
                      placeholder="John Doe"
                    />
                  </div>
                  {/* Phone */}
                  <div className="border-b border-black/20 pb-1">
                    <label className="block text-[9px] uppercase tracking-widest font-bold opacity-60 mb-1">Phone</label>
                    <input
                      required
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full bg-transparent text-sm font-medium focus:outline-none placeholder-black/30 text-black py-2"
                      placeholder="+1 (555) 000-0000"
                    />
                  </div>
                </div>

                {/* Email */}
                <div className="border-b border-black/20 pb-1">
                  <label className="block text-[9px] uppercase tracking-widest font-bold opacity-60 mb-1">Email Address</label>
                  <input
                    required
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-transparent text-sm font-medium focus:outline-none placeholder-black/30 text-black py-2"
                    placeholder="john@example.com"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Date */}
                  <div className="border-b border-black/20 pb-1">
                    <label className="block text-[9px] uppercase tracking-widest font-bold opacity-60 mb-1">Date</label>
                    <div className="relative">
                      <input
                        required
                        type="date"
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        className="w-full bg-transparent text-sm font-medium focus:outline-none text-black py-2"
                      />
                    </div>
                  </div>
                  {/* Time */}
                  <div className="border-b border-black/20 pb-1">
                    <label className="block text-[9px] uppercase tracking-widest font-bold opacity-60 mb-1">Time</label>
                    <div className="relative">
                      <select
                        required
                        name="time"
                        value={formData.time}
                        onChange={handleChange}
                        className="w-full bg-transparent text-sm font-medium focus:outline-none text-black py-2 appearance-none"
                      >
                        <option value="" disabled>Select Time</option>
                        <option value="17:00">5:00 PM</option>
                        <option value="18:00">6:00 PM</option>
                        <option value="19:00">7:00 PM</option>
                        <option value="20:00">8:00 PM</option>
                        <option value="21:00">9:00 PM</option>
                        <option value="22:00">10:00 PM</option>
                      </select>
                    </div>
                  </div>
                  {/* Guests */}
                  <div className="border-b border-black/20 pb-1">
                    <label className="block text-[9px] uppercase tracking-widest font-bold opacity-60 mb-1">Guests</label>
                    <div className="relative">
                      <select
                        required
                        name="guests"
                        value={formData.guests}
                        onChange={handleChange}
                        className="w-full bg-transparent text-sm font-medium focus:outline-none text-black py-2 appearance-none"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8].map(num => (
                          <option key={num} value={num}>{num} Person{num > 1 ? 's' : ''}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-black text-white hover:bg-black/90 py-4 text-[10px] uppercase tracking-widest mt-4 transition-colors disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Processing...
                    </>
                  ) : (
                    'Confirm Booking'
                  )}
                </button>
              </motion.form>
            ) : (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12"
              >
                <div className="w-16 h-16 border-2 border-black/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-8 h-8 text-black" />
                </div>
                <h3 className="font-serif text-2xl font-bold mb-4">Booking Confirmed</h3>
                <p className="text-black/70 font-medium mb-8 max-w-sm mx-auto text-sm">
                  Thank you, {formData.name}. We sent details to {formData.email}.
                </p>
                <button
                  onClick={() => {
                    setFormData({ name: '', email: '', phone: '', date: '', time: '', guests: '2' });
                    setIsSuccess(false);
                  }}
                  className="text-black text-[10px] uppercase tracking-widest font-bold hover:opacity-70"
                >
                  Make another booking
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
}
